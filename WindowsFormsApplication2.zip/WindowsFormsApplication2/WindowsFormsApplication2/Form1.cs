﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public int iterations;
        public Cursor mouse;
        public int vecx;
        public int vecy;
        public Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            timer1.Interval = Convert.ToInt32(numericUpDown1.Value); ;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            timer2.Interval = Convert.ToInt32(numericUpDown2.Value);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.Cursor = new Cursor(Cursor.Current.Handle);
            Cursor.Position = new Point(Cursor.Position.X - vecx, Cursor.Position.Y - vecy);
            //Cursor.Clip = new Rectangle(0, 0, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            iterations++;
            if (Convert.ToInt32(iterations) == Convert.ToInt32(maxanims.Value))
            {
                timer2.Enabled = false;
                timer1.Enabled = true;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = true;
            
            iterations = 0;
            vecx = rnd.Next(20)-10;
            vecy = rnd.Next(20)-10;
            //MessageBox.Show(vecx.ToString());
            //MessageBox.Show(vecy.ToString());


        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void checkBoxEnable_CheckedChanged(object sender, EventArgs e)
        {
            timer1.Enabled = checkBoxEnable.Checked;
            timer2.Enabled = false;
        }
    }
}
